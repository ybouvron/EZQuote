Instructions:

1. Edit CMakeLists.txt to the name of .cpp file to be executed (ie "autocrop" if .cpp file is autocrop.cpp)
2. Edit "imread" function in .cpp file to contain the exact name and location of image
3. In terminal, cd to location of files and run command "cmake ." then "make"
4. Execute the newly created executable.
